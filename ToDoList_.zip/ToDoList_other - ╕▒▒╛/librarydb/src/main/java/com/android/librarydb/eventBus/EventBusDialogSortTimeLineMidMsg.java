package com.android.librarydb.eventBus;

public class EventBusDialogSortTimeLineMidMsg {
    private boolean is_success;
    public EventBusDialogSortTimeLineMidMsg(boolean is){
        is_success=is;
    }
    public boolean isIs_success() {
        return is_success;
    }
}
