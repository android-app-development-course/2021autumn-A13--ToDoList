package com.android.librarydb.constant;

public class URL {
    private static final String IP="10.242.81.124";
    public static final String URL ="http://"+IP+":9090/login";
}
