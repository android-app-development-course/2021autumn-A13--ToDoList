package com.android.librarydb.eventBus;

import com.android.librarydb.bean.CardBean;

public class EventBusSortTimeLineMidMsg {
    private boolean is_success;
    public EventBusSortTimeLineMidMsg(boolean is){
        is_success=is;
    }
    public boolean isIs_success() {
        return is_success;
    }
}
