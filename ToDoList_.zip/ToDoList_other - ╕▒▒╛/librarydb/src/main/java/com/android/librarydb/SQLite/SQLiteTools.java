package com.android.librarydb.SQLite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.android.librarybase.basemethod.GetTime;
import com.android.librarydb.bean.CardBean;
import com.android.librarydb.bean.TagBean;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static com.android.librarydb.SQLite.OrderDBHelperCards.*;
import static com.android.librarydb.SQLite.OrderDBHelperTags.TAG_COLOR;
import static com.android.librarydb.SQLite.OrderDBHelperTags.TAG_NAME;
import static com.android.librarydb.SQLite.OrderDBHelperTags.TAG_TABLE_NAME;

@SuppressLint("Range")
public class SQLiteTools {

    /**
     * 添加新标签
     * @param mContext
     * @param tag_name
     * @param tag_color
     */
    public static boolean insertTagDB(
            Context mContext,
            String tag_name,
            int tag_color){
        if(hasSameTagDB(mContext,tag_name))return false;
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperTags().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TAG_NAME, tag_name);
        contentValues.put(TAG_COLOR, tag_color);
        db.insert(TAG_TABLE_NAME, null, contentValues);
        return true;
    }

    /**
     * 删除标签
     * @param mContext
     * @param tag_name
     * @return
     */
    public static boolean deleteTagDB(
            Context mContext,
            String tag_name){
//        if(!hasSameTagDB(mContext,tag_name))return false;
        if (hasCard(mContext,tag_name))return false;
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperTags().getWritableDatabase();
        db.delete(TAG_TABLE_NAME, TAG_NAME + "= ?", new String[] { tag_name });
        return true;
    }

    /**
     * 获取所有标签名
     * @param mContext
     * @return
     */
    public static List<String> getTagNames(
            Context mContext){
        List<String>list=new ArrayList<>();
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperTags().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(TAG_TABLE_NAME, new String[]{
                        TAG_NAME}, "",
                new String[]{}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            list.add(cursor.getString(cursor.getColumnIndex(TAG_NAME)));
        }
        // 关闭游标，释放资源
        cursor.close();
        return list;
    }

    /**
     * 根据标签名获取标签颜色
     * @param mContext
     * @param tag_name
     * @return
     */
    public static int getTagColorDB(
            Context mContext,
            String tag_name){
        int result=0;
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperTags().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(TAG_TABLE_NAME, new String[]{
                TAG_COLOR}, " tag_name = ?",
                new String[]{tag_name}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            result = cursor.getInt(cursor.getColumnIndex(TAG_COLOR));
        }
        // 关闭游标，释放资源
        cursor.close();
        return result;
    }



    /**
     * 根据标签名查看是否已有该标签
     * @param mContext
     * @param tag_name
     * @return
     */
    public static boolean hasSameTagDB(
            Context mContext,
            String tag_name){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperTags().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(TAG_TABLE_NAME, new String[]{
                        }, " tag_name = ?",
                new String[]{tag_name}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            cursor.close();
            return true;
        }
        // 关闭游标，释放资源
        cursor.close();
        return false;
    }

    /**
     * 新建计划
     * @param mContext
     * @param tag_name
     * @param card_name
     * @param is_finish
     * @param start_time
     * @param end_time
     * @param content
     */
    public static void insertCardDB(
            Context mContext,
            String tag_name,
            String card_name,
            boolean is_finish,
            long start_time,
            long end_time,
            String content,
            boolean is_all_day){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TAG_NAME, tag_name);
        contentValues.put(CARD_NAME, card_name);
        contentValues.put(IS_FINISH, is_finish?1:0);
        contentValues.put(START_TIME, String.valueOf(start_time));
        contentValues.put(END_TIME, String.valueOf(end_time));
        contentValues.put(CONTENT, content);
        contentValues.put(IN_GET_BACK, 0);
        contentValues.put(IS_ALL_DAY, is_all_day?1:0);
        db.insert(CARD_TABLE_NAME, null, contentValues);
    }

    /**
     * 假删除计划
     * @param mContext
     * @param card_id
     */
    public static void fakeDeleteCardDB(
            Context mContext,
            int card_id){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(IN_GET_BACK, 1);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }

    /**
     * 真删除计划
     * @param mContext
     * @param card_id
     */
    public static void realDeleteCardDB(
            Context mContext,
            int card_id){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        db.delete(CARD_TABLE_NAME, CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }

    /**
     * 取回回收站的计划
     * @param mContext
     * @param card_id
     */
    public static void getBackCardDB(
            Context mContext,
            int card_id){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(IN_GET_BACK, 0);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }

    /**
     * 整一条更新计划
     * @param card_id
     * @param mContext
     * @param tag_name
     * @param card_name
     * @param is_finish
     * @param start_time
     * @param end_time
     * @param content
     */
    public static void updateCardDB(
            Context mContext,
            int card_id,
            String tag_name,
            String card_name,
            boolean is_finish,
            long start_time,
            long end_time,
            String content,
            boolean is_all_day){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TAG_NAME, tag_name);
        contentValues.put(CARD_NAME, card_name);
        contentValues.put(IS_FINISH, is_finish?1:0);
        contentValues.put(START_TIME, String.valueOf(start_time));
        contentValues.put(END_TIME, String.valueOf(end_time));
        contentValues.put(CONTENT, content);
        contentValues.put(IS_ALL_DAY, is_all_day?1:0);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }

    /**
     * 更新计划
     * @param mContext
     * @param card_id
     * @param key
     * @param value
     */
    public static void updateCardDB(
            Context mContext,
            int card_id,
            String key,
            int value){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(key, value);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }
    public static void updateCardDB(
            Context mContext,
            int card_id,
            String key,
            String value){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(key, value);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }
    public static void updateCardDB(
            Context mContext,
            int card_id,
            String key,
            long value){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(key, value);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }
    public static void updateCardDB(
            Context mContext,
            int card_id,
            String key,
            boolean value){
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(key, value?1:0);
        db.update(CARD_TABLE_NAME, contentValues,CARD_ID + " = ? ", new String[] { String.valueOf(card_id) });
    }

    /**
     * 获取持久化数据下的所有计划
     * @param mContext
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("Range")
    public static List<CardBean> getAllCards(Context mContext,boolean is_reverse,boolean is_start,int put_is_finish){
        List<CardBean>cards=new ArrayList<>();
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(CARD_TABLE_NAME, new String[]{
                CARD_ID, TAG_NAME, CARD_NAME, IS_FINISH ,START_TIME, END_TIME, CONTENT, IN_GET_BACK ,IS_ALL_DAY}, "",
                new String[]{}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            int in_get_back = cursor.getInt(cursor.getColumnIndex(IN_GET_BACK));
            if(in_get_back==1)continue;
            boolean is_finish = cursor.getInt(cursor.getColumnIndex(IS_FINISH)) == 1;
            if(put_is_finish==1){
                if(!is_finish)continue;
            }
            else if(put_is_finish==0){
                if(is_finish)continue;
            }
            int card_id = cursor.getInt(cursor.getColumnIndex(CARD_ID));
            String card_name = cursor.getString(cursor.getColumnIndex(CARD_NAME));
            String tag_name = cursor.getString(cursor.getColumnIndex(TAG_NAME));
            long start_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(START_TIME)));
            long end_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(END_TIME)));
            String content = cursor.getString(cursor.getColumnIndex(CONTENT));

            int tag_color= getTagColorDB(mContext,tag_name);
            boolean is_all_day = cursor.getInt(cursor.getColumnIndex(IS_ALL_DAY)) == 1;
            cards.add(new CardBean(card_id,tag_name,card_name,start_time,end_time,content,tag_color,is_finish,is_all_day));
        }
        // 关闭游标，释放资源
        cursor.close();
        if (is_start){
            if(is_reverse)cards.sort(Comparator.comparing(CardBean::getStart_time).reversed());
            else cards.sort(Comparator.comparing(CardBean::getStart_time));
        }
        else{
            if(is_reverse)cards.sort(Comparator.comparing(CardBean::getEnd_time).reversed());
            else cards.sort(Comparator.comparing(CardBean::getEnd_time));
        }
        cards.sort(Comparator.comparing(CardBean::getInt_is_finish));
        return cards;
    }

    /**
     * 获取持久化数据下的所有回收站的计划
     * @param mContext
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("Range")
    public static List<CardBean> getAllGetBackCards(Context mContext,boolean is_reverse){
        List<CardBean>cards=new ArrayList<>();
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(CARD_TABLE_NAME, new String[]{
                        CARD_ID, TAG_NAME, CARD_NAME, IS_FINISH ,START_TIME, END_TIME, CONTENT, IN_GET_BACK,IS_ALL_DAY}, "",
                new String[]{}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            int in_get_back = cursor.getInt(cursor.getColumnIndex(IN_GET_BACK));
            if(in_get_back==0)continue;
            int card_id = cursor.getInt(cursor.getColumnIndex(CARD_ID));
            String card_name = cursor.getString(cursor.getColumnIndex(CARD_NAME));
            String tag_name = cursor.getString(cursor.getColumnIndex(TAG_NAME));
            long start_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(START_TIME)));
            long end_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(END_TIME)));
            String content = cursor.getString(cursor.getColumnIndex(CONTENT));
            boolean is_finish = cursor.getInt(cursor.getColumnIndex(IS_FINISH)) == 1;
            int tag_color= getTagColorDB(mContext,tag_name);
            boolean is_all_day = cursor.getInt(cursor.getColumnIndex(IS_ALL_DAY)) == 1;
            cards.add(new CardBean(card_id,tag_name,card_name,start_time,end_time,content,tag_color,is_finish,is_all_day));
        }
        // 关闭游标，释放资源
        cursor.close();
        if(is_reverse)cards.sort(Comparator.comparing(CardBean::getStart_time).reversed());
        else cards.sort(Comparator.comparing(CardBean::getStart_time));
        cards.sort(Comparator.comparing(CardBean::getInt_is_finish));
        return cards;
    }


    /**
     * 选择指定时间的计划
     * @param mContext
     * @param mTime
     * @param is_reverse
     * @param is_start
     * @param is_pre
     * @param put_is_finish -1为全部 0为未完成 1为已完成
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("Range")
    public static List<CardBean> getSelectTimeCards(Context mContext,long mTime,boolean is_reverse,boolean is_start,boolean is_pre,int put_is_finish){
        List<CardBean>cards=new ArrayList<>();
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(CARD_TABLE_NAME, new String[]{
                        CARD_ID, TAG_NAME, CARD_NAME, IS_FINISH ,START_TIME, END_TIME, CONTENT, IN_GET_BACK,IS_ALL_DAY}, "",
                new String[]{}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            int in_get_back = cursor.getInt(cursor.getColumnIndex(IN_GET_BACK));
            if(in_get_back==1)continue;
            boolean is_finish = cursor.getInt(cursor.getColumnIndex(IS_FINISH)) == 1;
            if(put_is_finish==1){
                if(!is_finish)continue;
            }
            else if(put_is_finish==0){
                if(is_finish)continue;
            }
            long start_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(START_TIME)));
            long end_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(END_TIME)));
            //==========================判断时间的包含关系==============================
            int baohanguanxi=-1;
            try {
                baohanguanxi=GetTime.checkTime(start_time,end_time,mTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if (baohanguanxi==-1)continue;
            Log.e("time01",GetTime.getNowTimeStr(mTime,"yyyy/MM/dd"));
            Log.e("time02",GetTime.getNowTimeStr(start_time,"yyyy/MM/dd"));
            int card_id = cursor.getInt(cursor.getColumnIndex(CARD_ID));
            String card_name = cursor.getString(cursor.getColumnIndex(CARD_NAME));
            String tag_name = cursor.getString(cursor.getColumnIndex(TAG_NAME));
            String content = cursor.getString(cursor.getColumnIndex(CONTENT));
            int tag_color= getTagColorDB(mContext,tag_name);
            boolean is_all_day = cursor.getInt(cursor.getColumnIndex(IS_ALL_DAY)) == 1;
            cards.add(new CardBean(card_id,tag_name,card_name,start_time,end_time,content,tag_color,is_finish,is_all_day));
        }
        // 关闭游标，释放资源
        cursor.close();
        if (is_start){
            if(is_reverse)cards.sort(Comparator.comparing(CardBean::getStart_time).reversed());
            else cards.sort(Comparator.comparing(CardBean::getStart_time));
        }
        else{
            if(is_reverse)cards.sort(Comparator.comparing(CardBean::getEnd_time).reversed());
            else cards.sort(Comparator.comparing(CardBean::getEnd_time));
        }
        if (is_pre){
            cards.sort(Comparator.comparing(CardBean::getInt_is_all_day).reversed());
        }
        else{
            cards.sort(Comparator.comparing(CardBean::getInt_is_all_day));
        }
        cards.sort(Comparator.comparing(CardBean::getInt_is_finish));
        return cards;
    }

    /**
     * 选择指定标签的计划
     * @param mContext
     * @param mTagName
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("Range")
    public static List<CardBean> getSelectTagCards(Context mContext,String mTagName,boolean is_reverse,boolean is_start,int put_is_finish){
        List<CardBean>cards=new ArrayList<>();
        if(mTagName.equals("所有")){
            cards=getAllCards(mContext,is_reverse,is_start,put_is_finish);
            return cards;
        }
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(CARD_TABLE_NAME, new String[]{
                        CARD_ID, TAG_NAME, CARD_NAME, IS_FINISH ,START_TIME, END_TIME, CONTENT, IN_GET_BACK,IS_ALL_DAY}, "",
                new String[]{}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            int in_get_back = cursor.getInt(cursor.getColumnIndex(IN_GET_BACK));
            if(in_get_back==1)continue;
            boolean is_finish = cursor.getInt(cursor.getColumnIndex(IS_FINISH)) == 1;
            if(put_is_finish==1){
                if(!is_finish)continue;
            }
            else if(put_is_finish==0){
                if(is_finish)continue;
            }
            String tag_name = cursor.getString(cursor.getColumnIndex(TAG_NAME));
            if (!tag_name.equals(mTagName))continue;
            long start_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(START_TIME)));
            int card_id = cursor.getInt(cursor.getColumnIndex(CARD_ID));
            String card_name = cursor.getString(cursor.getColumnIndex(CARD_NAME));
            long end_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(END_TIME)));
            String content = cursor.getString(cursor.getColumnIndex(CONTENT));

            int tag_color= getTagColorDB(mContext,tag_name);
            boolean is_all_day = cursor.getInt(cursor.getColumnIndex(IS_ALL_DAY)) == 1;
            cards.add(new CardBean(card_id,tag_name,card_name,start_time,end_time,content,tag_color,is_finish,is_all_day));
        }
        // 关闭游标，释放资源
        cursor.close();
        if (is_start){
            if(is_reverse)cards.sort(Comparator.comparing(CardBean::getStart_time).reversed());
            else cards.sort(Comparator.comparing(CardBean::getStart_time));
        }
        else{
            if(is_reverse)cards.sort(Comparator.comparing(CardBean::getEnd_time).reversed());
            else cards.sort(Comparator.comparing(CardBean::getEnd_time));
        }
        cards.sort(Comparator.comparing(CardBean::getInt_is_finish));
        return cards;
    }


    /**
     * 获取持久化数据下的指定card——id的计划
     * @param mContext
     * @return
     */
    @SuppressLint("Range")
    public static CardBean getCard(Context mContext,int card_id){
        CardBean card = null;
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(CARD_TABLE_NAME, new String[]{
                        CARD_ID, TAG_NAME, CARD_NAME, IS_FINISH ,START_TIME, END_TIME, CONTENT, IN_GET_BACK,IS_ALL_DAY}, CARD_ID+" = ? ",
                new String[]{String.valueOf(card_id)}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
//            int card_id = cursor.getInt(cursor.getColumnIndex(CARD_ID));
            String card_name = cursor.getString(cursor.getColumnIndex(CARD_NAME));
            String tag_name = cursor.getString(cursor.getColumnIndex(TAG_NAME));
            long start_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(START_TIME)));
            long end_time = Long.parseLong(cursor.getString(cursor.getColumnIndex(END_TIME)));
            String content = cursor.getString(cursor.getColumnIndex(CONTENT));
            boolean is_finish = cursor.getInt(cursor.getColumnIndex(IS_FINISH)) == 1;
            int tag_color= getTagColorDB(mContext,tag_name);
            boolean is_all_day = cursor.getInt(cursor.getColumnIndex(IS_ALL_DAY)) == 1;
            card=new CardBean(card_id,tag_name,card_name,start_time,end_time,content,tag_color,is_finish,is_all_day);
        }
        // 关闭游标，释放资源
        cursor.close();
        return card;
    }

    public static List<TagBean> getAllTags(Context mContext) {
        List<TagBean>tags=new ArrayList<>();
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperTags().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(TAG_TABLE_NAME, new String[]{
                        TAG_NAME,TAG_COLOR}, "",
                new String[]{}, null, null, null);
        //利用游标遍历所有数据对象
        while(cursor.moveToNext()){
            String tag_name = cursor.getString(cursor.getColumnIndex(TAG_NAME));
            int tag_color = cursor.getInt(cursor.getColumnIndex(TAG_COLOR));
            tags.add(new TagBean(tag_name,tag_color));
        }
        // 关闭游标，释放资源
        cursor.close();
        return tags;
    }

    /**
     * 根据标签名判断是否有对应的计划
     * @param mContext
     * @param tag_name
     * @return
     */
    public static boolean hasCard(Context mContext, String tag_name) {
        List<TagBean>tags=new ArrayList<>();
        SQLiteDatabase db;
        OrderDAO orderDAO =new OrderDAO(mContext);
        db = orderDAO.getOrderDBHelperCards().getReadableDatabase();
        //创建游标对象
        Cursor cursor = db.query(CARD_TABLE_NAME, new String[]{
                        CARD_ID}, TAG_NAME+" = ? ",
                new String[]{tag_name}, null, null, null);
        //利用游标遍历所有数据对象
        boolean has=false;
        while(cursor.moveToNext()){
            has = true;
            break;
        }
        // 关闭游标，释放资源
        cursor.close();
        return has;
    }
}
