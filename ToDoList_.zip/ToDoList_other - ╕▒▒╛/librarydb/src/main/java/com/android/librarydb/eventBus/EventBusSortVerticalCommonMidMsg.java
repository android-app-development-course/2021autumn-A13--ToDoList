package com.android.librarydb.eventBus;

public class EventBusSortVerticalCommonMidMsg {
    private boolean is_success;
    
    public EventBusSortVerticalCommonMidMsg(boolean is){
        is_success=is;
    }
    public boolean isIs_success() {
        return is_success;
    }
}
