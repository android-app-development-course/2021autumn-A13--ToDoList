package com.android.librarydb.request;

import com.android.librarydb.bean.travelBean;
import com.android.librarydb.bean.workBean;
import com.android.librarydb.constant.URL;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class accountRequest {
    //cookie存放
    private final HashMap<String, List<Cookie> > cookieStore = new HashMap<String, List<Cookie> >();
    //具有cookie维护功能的OkHttp客户端
    private OkHttpClient okHttpClient = new OkHttpClient.Builder().cookieJar(new CookieJar() {
        public void saveFromResponse(HttpUrl httpUrl, List<Cookie> list) {
            cookieStore.put(httpUrl.host(), list);
        }

        public List<Cookie> loadForRequest(HttpUrl httpUrl) {
            List<Cookie> cookies = cookieStore.get(httpUrl.host());
            return cookies != null ? cookies : new ArrayList<Cookie>();
        }
    }).build();

    //------------------------操作account 表------------------------
    /**
     * - 登录功能
     * - 返回 true 登录成功
     * - 返回 false 登录失败
     * */
    public boolean login(String userName,String password) throws IOException {
        //封装数据
        FormBody formBody = new FormBody.Builder()
                .add("userName",userName)
                .add("password",password)
                .build();
        //封装请求
        Request request = new Request.Builder().url(URL.URL).post(formBody).build();
        //发送请求
        Call call = okHttpClient.newCall(request);
        //获取响应
        Response response = call.execute();
        //打印响应
        //showResponseInfo(response);
        //返回结果
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 注册功能
     * - 返回 true 注册成功
     * - 返回 false 用户已存在 请直接登录
     * */
    public boolean register(String userName,String password) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("userName",userName)
                .add("password",password)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/register").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        //showResponseInfo(response);
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 登出
     * */
    public boolean logout() throws IOException {
        FormBody formBody = new FormBody.Builder().build();
        Request request = new Request.Builder().url("http://localhost:9090/logout").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 修改信息
     * */
    public boolean updateInfo(String sex,String headPortrait,String describe) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("sex",sex)
                .add("headPortrait",headPortrait)
                .add("describe",describe)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/updateInfo").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    //------------------------操作travel 表------------------------
    /**
     * - 获取所有出行计划
     * */
    public List<travelBean> getTravel() throws IOException {
        FormBody formBody = new FormBody.Builder().build();
        Request request = new Request.Builder().url("http://localhost:9090/getTravel").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        //showResponseInfo(response);
        Gson gson = new Gson();
        Type travelListType = new TypeToken<ArrayList<travelBean> >(){}.getType();
        String str = response.body().string();
        List<travelBean> travelBeans = gson.fromJson(str, travelListType);
        return travelBeans;
    }

    /**
     * - 添加出行计划
     * - 返回 true 添加成功
     * - 返回 false 出行计划同名 请修改出行计划名字
     * */
    public boolean addTravel(String travelName,String startTime,String endTime,String travelTag,String travelDestination,String travelDescribe) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("travelName",travelName)
                .add("startTime",startTime)
                .add("endTime",endTime)
                .add("travelTag",travelTag)
                .add("travelDestination",travelDestination)
                .add("travelDescribe",travelDescribe)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/addTravel").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 删除出行计划
     */
    public boolean deleteTravel(String travelName) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("travelName",travelName)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/deleteTravel").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 修改出行计划
     * */
    public boolean updateTravel(String travelName,String startTime,String endTime,String travelTag,String travelDestination,String travelDescribe) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("travelName",travelName)
                .add("startTime",startTime)
                .add("endTime",endTime)
                .add("travelTag",travelTag)
                .add("travelDestination",travelDestination)
                .add("travelDescribe",travelDescribe)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/updateTravel").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    //------------------------操作work 表------------------------
    /**
     * - 获取任务
     * */
    public List<workBean>getWork(String workTag) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("workTag",workTag)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/getWork").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        Gson gson = new Gson();
        Type workListType = new TypeToken<ArrayList<workBean> >(){}.getType();
        String str = response.body().string();
        List<workBean> workBeans = gson.fromJson(str, workListType);
        return workBeans;
    }

    /**
     * - 添加任务
     * - 返回 true 添加成功
     * - 返回 false 任务名重复 请修改任务名
     * */
    public boolean addWork(String workName,String startTime,String endTime,String workDescribe) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("workName",workName)
                .add("startTime",startTime)
                .add("endTime",endTime)
                .add("workDescribe",workDescribe)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/addWork").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 删除任务
     * */
    public boolean deleteWork(String workName) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("workName",workName)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/deleteWork").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * - 修改任务
     * */
    public boolean updateWork(String workName,String startTime,String endTime,String workDescribe) throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("workName",workName)
                .add("startTime",startTime)
                .add("endTime",endTime)
                .add("workDescribe",workDescribe)
                .build();
        Request request = new Request.Builder().url("http://localhost:9090/updateWork").post(formBody).build();
        Call call = okHttpClient.newCall(request);
        Response response = call.execute();
        if(response.toString().indexOf("code=200") > -1)
            return true;
        return false;
    }

    /**
     * 打印响应报文内容
     * */
    private void showResponseInfo(Response response) throws IOException {
        System.out.println("abstract info:");
        System.out.println(response.toString());
        System.out.println("header:");
        System.out.println(response.headers().toString());
        System.out.println("body:");
        System.out.println(response.body().string());
    }

    public static void main(String[] args) throws IOException {
        //声明一个用于发送请求的对象
        accountRequest accountRequest = new accountRequest();

        /**
         * 1. 登录请求
         * */
        boolean login = accountRequest.login("1232", "123");
        if(login){
            System.out.println("登录成功");
        }else{
            System.out.println("登录失败");
        }

        /**
         * 2. 注册请求
         */
//        boolean register = accountRequest.register("zpt", "123");
//        if(register){
//            System.out.println("注册成功");
//        }else{
//            System.out.println("用户已存在，请直接登录");
//        }

        /**
         * 3. 登出
         * */
//        boolean logout = accountRequest.logout();
//        if(logout){
//            System.out.println("登出成功");
//        }else{
//            System.out.println("登出失败");
//        }

        /**
         * 4. 修改信息
         * */
//        boolean check = accountRequest.updateInfo("男", "head", "人");
//        if(check){
//            System.out.println("修改成功");
//        }else{
//            System.out.println("修改失败");
//        }

        /**
         * 1. 获取所有出行计划
         * */
        //List<travelBean> travels = accountRequest.getTravel();
        //System.out.println(travels);

        /**
         * 2. 添加出行计划
         * */
//        boolean check = accountRequest.addTravel("去汕头", "2021-02-22 10:10:10","2022-02-22 10:10:10","出远门","汕头","应该很无聊");
//        if(check){
//            System.out.println("添加成功");
//        }else{
//            System.out.println("出行计划名字重复，请修改出行计划名");
//        }

        /**
         * 3. 删除出行计划
         * */
//        boolean check = accountRequest.deleteTravel("去汕头");
//        if(check){
//            System.out.println("删除成功");
//        }else{
//            System.out.println("删除失败");
//        }

        /**
         * 4. 修改出行计划
         * */
//        boolean check2 = accountRequest.updateTravel("去汕头", "2021-02-22 10:10:10","2022-02-22 10:10:10","出远门","汕头","会很有趣");
//        if(check2){
//            System.out.println("修改成功");
//        }else{
//            System.out.println("修改失败");
//        }

        /**
         * 1. 获取任务
         * */
//        List<workBean> unfinished = accountRequest.getWork("unfinished");
//        System.out.println(unfinished);

        /**
         * 2. 添加任务
         * */
//        boolean check = accountRequest.addWork("写编译原理", "2000-01-22 10:10:10", "2010-01-22 10:10:10", "很难的作业");
//        if(check){
//            System.out.println("添加成功");
//        }else{
//            System.out.println("任务名重复，请修改任务名");
//        }

        /**
         * 3. 删除任务
         * */
//        boolean check = accountRequest.deleteWork("写编译原理");
//        if(check){
//            System.out.println("删除成功");
//        }else{
//            System.out.println("删除失败");
//        }

        /**
         * 4. 修改任务
         * */
//        boolean check2 = accountRequest.updateWork("写编译原理", "2000-01-22 10:10:10", "2010-01-22 10:10:10", "很简单的作业");
//        if(check2){
//            System.out.println("修改成功");
//        }else{
//            System.out.println("修改失败");
//        }

    }

}
