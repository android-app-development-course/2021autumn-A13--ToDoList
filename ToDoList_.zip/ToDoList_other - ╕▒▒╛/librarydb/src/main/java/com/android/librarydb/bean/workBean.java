package com.android.librarydb.bean;

import java.util.Date;

public class workBean {
    private int workId;
    private int accountId;
    private String workName;
    private Date startTime;
    private Date endTime;
    private String workDescribe;
    private String workTag;
    private int performance;

    @Override
    public String toString() {
        return "workBean{" +
                "workId=" + workId +
                ", accountId=" + accountId +
                ", workName='" + workName + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", workDescribe='" + workDescribe + '\'' +
                ", workTag='" + workTag + '\'' +
                ", performance=" + performance +
                '}';
    }

    public int getWorkId() {
        return workId;
    }

    public void setWorkId(int workId) {
        this.workId = workId;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public String getWorkName() {
        return workName;
    }

    public void setWorkName(String workName) {
        this.workName = workName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getWorkDescribe() {
        return workDescribe;
    }

    public void setWorkDescribe(String workDescribe) {
        this.workDescribe = workDescribe;
    }

    public String getWorkTag() {
        return workTag;
    }

    public void setWorkTag(String workTag) {
        this.workTag = workTag;
    }

    public int getPerformance() {
        return performance;
    }

    public void setPerformance(int performance) {
        this.performance = performance;
    }
}
