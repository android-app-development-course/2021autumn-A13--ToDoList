package com.android.librarydb.bean;

import java.util.Date;

public class travelBean {
    private int travelId;
    private int accountId;
    private Date startTime;
    private Date endTime;
    private String travelTag;

    @Override
    public String toString() {
        return "travelBean{" +
                "travelId=" + travelId +
                ", accountId=" + accountId +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", travelTag='" + travelTag + '\'' +
                ", travelName='" + travelName + '\'' +
                ", travelDestination='" + travelDestination + '\'' +
                ", travelDescribe='" + travelDescribe + '\'' +
                '}';
    }

    private String travelName;
    private String travelDestination;
    private String travelDescribe;

    public int getTravelId() {
        return travelId;
    }

    public void setTravelId(int travelId) {
        this.travelId = travelId;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getTravelTag() {
        return travelTag;
    }

    public void setTravelTag(String travelTag) {
        this.travelTag = travelTag;
    }

    public String getTravelName() {
        return travelName;
    }

    public void setTravelName(String travelName) {
        this.travelName = travelName;
    }

    public String getTravelDestination() {
        return travelDestination;
    }

    public void setTravelDestination(String travelDestination) {
        this.travelDestination = travelDestination;
    }

    public String getTravelDescribe() {
        return travelDescribe;
    }

    public void setTravelDescribe(String travelDescribe) {
        this.travelDescribe = travelDescribe;
    }
}
