package com.android.librarybase.constant;

public class ARouterActivityPath {
    /**
     * MainPage组件
     */
    public static class Main {
        private static final String MAIN = "/main";

        /**
         * 主页面
         */
        public static final String PAGER_MAIN = MAIN + "/MainPageActivity";
    }
    /**
     * LoginPage组件
     */
    public static class Login {
        private static final String LOGIN = "/login";

        /**
         * 主页面
         */
        public static final String PAGER_LOGIN = LOGIN + "/LoginPageActivity";
    }
    /**
     * plan详情组件
     */
    public static class PlanDetail {
        private static final String PLAN = "/Detail";

        /**
         * 主页面
         */
        public static final String PLAN_DETAIL = PLAN + "/PlanDetailActivity";
    }
}
