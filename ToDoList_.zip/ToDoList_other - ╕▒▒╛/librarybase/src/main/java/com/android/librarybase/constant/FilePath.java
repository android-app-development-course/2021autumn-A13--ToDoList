package com.android.librarybase.constant;

public class FilePath {
    /**
     * 存储登录信息的文件
     */
    public static final String LOGIN_MSG_FILE = "LoginMsgFile";
    /**
     * 存储标签信息的文件
     */
    public static final String TAGS_MSG_FILE = "TagMsgFile";
}
