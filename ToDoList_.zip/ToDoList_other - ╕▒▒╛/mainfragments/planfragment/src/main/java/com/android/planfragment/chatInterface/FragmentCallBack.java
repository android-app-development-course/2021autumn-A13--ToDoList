package com.android.planfragment.chatInterface;

import java.util.HashMap;

public interface FragmentCallBack {
    void sendMsg(HashMap<String,Object>t);

}
