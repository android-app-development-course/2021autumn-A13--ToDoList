package com.android.planfragment.chineseCalendar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.android.librarybase.basemethod.GetTime;
import com.android.librarydb.eventBus.EventBusSelectTimeMidMsg;
import com.android.planfragment.R;
import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.CalendarLayout;
import com.haibin.calendarview.CalendarView;
import com.qmuiteam.qmui.layout.QMUILinearLayout;

import org.greenrobot.eventbus.EventBus;


public class CustomInit implements
        CalendarView.OnCalendarSelectListener,
        CalendarView.OnYearChangeListener{


    private TextView mTextMonthDay;
    private TextView mTextYear;
    private TextView mTextLunar;
    private TextView mTextCurrentDay;
    private CalendarView mCalendarView;
    private RelativeLayout mRelativeTool;
    private FrameLayout mFlToday;
    private int mYear;
    private CalendarLayout mCalendarLayout;
    private View mRootView;
    public CustomInit(View view){
        mRootView=view;
    }
    private void setListener(){
        //点击月打开月视图和年视图
//        mTextMonthDay.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (!mCalendarLayout.isExpand()) {
//                    mCalendarLayout.expand();
//                    return;
//                }
//                mCalendarView.showYearSelectLayout(mYear);
//                mTextLunar.setVisibility(View.GONE);
//                mTextYear.setVisibility(View.GONE);
//                mTextMonthDay.setText(String.valueOf(mYear));
//            }
//        });
        mFlToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCalendarView.scrollToCurrent();
                mTextLunar.setText("今日");
            }
        });
    }
    public void customInitView(){
        mTextMonthDay = mRootView.findViewById(R.id.tv_month_day);
        mTextYear = mRootView.findViewById(R.id.tv_year);
        mTextLunar = mRootView.findViewById(R.id.tv_lunar);
        mRelativeTool = mRootView.findViewById(R.id.rl_tool);
        mCalendarView =  mRootView.findViewById(R.id.calendarView);
        mTextCurrentDay =  mRootView.findViewById(R.id.tv_current_day);
        mFlToday = mRootView.findViewById(R.id.fl_current);
        mCalendarLayout = mRootView.findViewById(R.id.calendarLayout);
        mCalendarView.setOnCalendarSelectListener(this);
        mCalendarView.setOnYearChangeListener(this);
        mTextYear.setText(String.valueOf(mCalendarView.getCurYear()));
        mYear = mCalendarView.getCurYear();
        mTextMonthDay.setText(mCalendarView.getCurMonth() + "月" + mCalendarView.getCurDay() + "日");
        mTextLunar.setText("今日");
        mTextCurrentDay.setText(String.valueOf(mCalendarView.getCurDay()));

        /*
        * 设置监听器
        * */
        setListener();
    }
    public void customInitData(){
//        int year = mCalendarView.getCurYear();
//        int month = mCalendarView.getCurMonth();
        //设置标记
/*
        Map<String, Calendar> map = new HashMap<>();
        map.put(getSchemeCalendar(year, month, 3, 0xFF40db25, "假").toString(),
                getSchemeCalendar(year, month, 3, 0xFF40db25, "假"));
        map.put(getSchemeCalendar(year, month, 6, 0xFFe69138, "事").toString(),
                getSchemeCalendar(year, month, 6, 0xFFe69138, "事"));
        map.put(getSchemeCalendar(year, month, 9, 0xFFdf1356, "议").toString(),
                getSchemeCalendar(year, month, 9, 0xFFdf1356, "议"));
        map.put(getSchemeCalendar(year, month, 13, 0xFFedc56d, "记").toString(),
                getSchemeCalendar(year, month, 13, 0xFFedc56d, "记"));
        map.put(getSchemeCalendar(year, month, 14, 0xFFedc56d, "记").toString(),
                getSchemeCalendar(year, month, 14, 0xFFedc56d, "记"));
        map.put(getSchemeCalendar(year, month, 15, 0xFFaacc44, "假").toString(),
                getSchemeCalendar(year, month, 15, 0xFFaacc44, "假"));
        map.put(getSchemeCalendar(year, month, 18, 0xFFbc13f0, "记").toString(),
                getSchemeCalendar(year, month, 18, 0xFFbc13f0, "记"));
        map.put(getSchemeCalendar(year, month, 25, 0xFF13acf0, "假").toString(),
                getSchemeCalendar(year, month, 25, 0xFF13acf0, "假"));
        map.put(getSchemeCalendar(year, month, 27, 0xFF13acf0, "多").toString(),
                getSchemeCalendar(year, month, 27, 0xFF13acf0, "多"));
        //此方法在巨大的数据量上不影响遍历性能，推荐使用
        mCalendarView.setSchemeDate(map);
*/
    }

    @Override
    public void onCalendarOutOfRange(Calendar calendar) {

    }

    @Override
    public void onCalendarSelect(Calendar calendar, boolean isClick) {
        mTextLunar.setVisibility(View.VISIBLE);
        mTextYear.setVisibility(View.VISIBLE);
        mTextMonthDay.setText(calendar.getMonth() + "月" + calendar.getDay() + "日");
        mTextYear.setText(String.valueOf(calendar.getYear()));
        if(calendar.getDay()!=mCalendarView.getCurDay())mTextLunar.setText(calendar.getLunar());
        else mTextLunar.setText("今日");

        mYear = calendar.getYear();

        Log.e("onDateSelected", "  -- " + calendar.getYear() +
                "  --  " + calendar.getMonth() +
                "  -- " + calendar.getDay() +
                "  --  " + isClick + "  --   " + calendar.getScheme());


        long mTime = GetTime.timeToStamp(calendar.getYear() + "/" + calendar.getMonth() + "/" + calendar.getDay(),"yyyy/MM/dd");
        EventBus.getDefault().post(new EventBusSelectTimeMidMsg(true,mTime));

    }

    @Override
    public void onYearChange(int year) {

    }
}
