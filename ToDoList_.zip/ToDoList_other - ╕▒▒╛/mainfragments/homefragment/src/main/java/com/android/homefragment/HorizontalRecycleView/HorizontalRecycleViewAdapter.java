package com.android.homefragment.HorizontalRecycleView;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.homefragment.LabelPageActivity;
import com.android.homefragment.R;

import java.util.List;

public class HorizontalRecycleViewAdapter extends RecyclerView.Adapter<HorizontalRecycleViewAdapter.InnerHolder> {

    private final List<ItemBean> mList;

    public HorizontalRecycleViewAdapter(List<ItemBean> data) {
        mList = data;
    }

    @NonNull
    @Override
    public InnerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(parent.getContext(), R.layout.recycle_view_item, null);
        InnerHolder innerHolder=new InnerHolder(view);
        innerHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parent.getContext().startActivity(new Intent(parent.getContext(), LabelPageActivity.class));
            }
        });
        return innerHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull InnerHolder holder, int position) {
        holder.setData(mList.get(position));
    }

    @Override
    public int getItemCount() {
        if (mList != null) {
            return mList.size();
        }
        return 0;
    }

    public class InnerHolder extends RecyclerView.ViewHolder {
        private final TextView textView;
        private final ImageView imageView;
        private final RelativeLayout r_layout_tab;

        public InnerHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.recycle_item_img);
            textView = itemView.findViewById(R.id.recycle_item_tv);
            r_layout_tab = itemView.findViewById(R.id.r_layout_tab);
        }

        public void setData(ItemBean itemBean) {
            textView.setText(itemBean.getScribe_text());
            imageView.setImageResource(itemBean.getImage_id());
            r_layout_tab.setBackgroundResource(itemBean.getBackground_id());
        }
    }
}
