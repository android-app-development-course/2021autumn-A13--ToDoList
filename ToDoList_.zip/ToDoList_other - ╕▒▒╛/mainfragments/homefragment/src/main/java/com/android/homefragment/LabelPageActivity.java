package com.android.homefragment;

import com.android.librarybase.basepage.BaseActivity;
import com.android.librarybase.topbarcolor.TopBar;

public class LabelPageActivity extends BaseActivity {


    @Override
    protected int getLayoutId() {
        return R.layout.activity_label_page;
    }

    @Override
    protected void initView() {
    }

    @Override
    protected void initData() {

    }
}