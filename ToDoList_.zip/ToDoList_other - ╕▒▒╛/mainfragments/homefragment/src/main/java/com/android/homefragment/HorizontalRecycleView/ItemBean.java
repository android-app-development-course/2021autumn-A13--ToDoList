package com.android.homefragment.HorizontalRecycleView;

public class ItemBean {

    private String scribe_text;
    private int image_id;
    private int background_id;

    public String getScribe_text() {
        return scribe_text;
    }

    public void setScribe_text(String scribe_text) {
        this.scribe_text = scribe_text;
    }

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }

    public int getBackground_id() {
        return background_id;
    }

    public void setBackground_id(int background_id) {
        this.background_id = background_id;
    }
}
