package com.android.homefragment.HorizontalRecycleView;

import com.android.homefragment.R;

public class Datas {
    public static int ids[]={
            R.drawable.study,
            R.drawable.go_out,
            R.drawable.food,
            R.drawable.traval,
            R.drawable.others};
    public static int background_ids[]={
            R.drawable.tab_shape_pink,
            R.drawable.tab_shape_yellow,
            R.drawable.tab_shape_other_pink,
            R.drawable.tab_shape_green,
            R.drawable.tab_shape_purple};
    public static String texts[]={"学习","出行","美食","游玩","其他"};
}
