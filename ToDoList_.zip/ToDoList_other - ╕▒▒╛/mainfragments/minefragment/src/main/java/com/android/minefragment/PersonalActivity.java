package com.android.minefragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.android.librarybase.basepage.BaseActivity;
import com.android.librarybase.topbarcolor.TopBar;
import com.xuexiang.xui.widget.actionbar.TitleBar;

public class PersonalActivity extends BaseActivity {

    @Override
    protected int getLayoutId() {

        return R.layout.activity_personal;
    }

    @Override
    protected void initView() {
        TopBar.setTopBarColor(PersonalActivity.this);
        TitleBar add_plan_top_bar=findViewById(R.id.personal_top_bar);
        add_plan_top_bar.setLeftClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(1);
                finish();
            }
        });
    }

    @Override
    protected void initData() {

    }

}