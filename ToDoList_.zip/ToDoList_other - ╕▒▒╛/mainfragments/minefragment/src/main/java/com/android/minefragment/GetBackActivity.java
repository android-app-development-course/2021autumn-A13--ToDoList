package com.android.minefragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.android.librarybase.basepage.BaseActivity;
import com.android.librarybase.topbarcolor.TopBar;
import com.xuexiang.xui.widget.actionbar.TitleBar;

public class GetBackActivity extends BaseActivity {

    @Override
    protected int getLayoutId() {

        return R.layout.activity_get_back;
    }

    @Override
    protected void initView() {
        TopBar.setTopBarColor(GetBackActivity.this);
        TitleBar add_plan_top_bar=findViewById(R.id.get_back_top_bar);
        add_plan_top_bar.setLeftClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(1);
                finish();
            }
        });
    }

    @Override
    protected void initData() {

    }

}