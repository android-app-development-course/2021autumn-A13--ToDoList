package com.android.minefragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.android.librarybase.basepage.BaseFragment;
import com.android.librarybase.constant.ARouterActivityPath;
import com.android.librarybase.constant.ARouterFragmentPath;
import com.android.librarybase.storage.SharedStorage;

@Route(path= ARouterFragmentPath.Mine.FRAG_MINE)
public class MineFragment extends BaseFragment {

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_mine;
    }

    @Override
    protected void initView() {
        if (SharedStorage.isLogin(mContext)){
            TextView text_header=mRootView.findViewById(R.id.text_header);
            text_header.setText("你的名字");
        }

        else {
            TextView text_header=mRootView.findViewById(R.id.text_header);
            text_header.setText("点击登录");
        }
        mRootView.findViewById(R.id.fan_kui).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(mRootView.getContext(),FanKuiActivity.class));
            }
        });
        mRootView.findViewById(R.id.set_labels).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(mRootView.getContext(),SetLabelsActivity.class));
            }
        });
        mRootView.findViewById(R.id.get_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(mRootView.getContext(),GetBackActivity.class));
            }
        });
        mRootView.findViewById(R.id.to_personal).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SharedStorage.isLogin(mContext))
                    startActivity(new Intent(mRootView.getContext(),PersonalActivity.class));
                else {
                    ARouter.getInstance().build(ARouterActivityPath.Login.PAGER_LOGIN).navigation();
                }
            }
        });
    }

    @Override
    protected void initData() {

    }
}
